class HomesController < ApplicationController
  def top
    #topアクションの実装
  end
end